# This file makes 'codecraftai' a Python package.
